///<reference path="./pixi.js.d.ts" />

class Main{
protected app:any;
protected graphics:any;
private x:number ;
private y:number;
private w:number ;
private h:number;
private r :number;
private c:any;

constructor()
{
this.app = new PIXI.Application(800, 600, { antialias: true , backgroundColor : 0x1099bb  } );
document.body.appendChild(this.app.view);
this.graphics = new PIXI.Graphics();
}

public drawLedge(x,y,w,h,c): any  {
this.graphics.beginFill(c);
this.graphics.drawRect(x,y,w,h);
this.graphics.endFill();
this.app.stage.addChild(this.graphics);
return this;
}
public drawCircle(x,y,r,c): any  {
    this.graphics.beginFill(c);
    this.graphics.drawCircle(x,y,r);
    this.graphics.endFill();
    this.app.stage.addChild(this.graphics);
    return this;
    }
}

var ob1 = new Main();
var paddle1 = ob1.drawLedge(10,100,10,100,0x00ff00);
var paddle2 = ob1.drawLedge(700,100,10,100,0x0000ff);
var ball = ob1.drawCircle(400,400,20,0xff0000);
var boundleft = ob1.drawLedge(0,0,0,600,0x00ff00);
var boundright = ob1.drawLedge(800,0,0,600,0x00ff00);
var boundup = ob1.drawLedge(0,0,800,0,0x00ff00);
var bounddown = ob1.drawLedge(0,600,800,0,0x00ff00);



